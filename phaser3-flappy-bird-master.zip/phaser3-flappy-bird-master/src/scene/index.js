import preload from './preload'
import menu from './menu'
import boot from './boot'
import play from './play'

export default [boot, preload, menu, play]